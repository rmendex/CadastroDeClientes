﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CadastroDeClientes.ServiceReference1;
using System.Text.RegularExpressions;

namespace CadastroDeClientes
{
    public partial class Cadastro : Form
    {
        public int _linhaIndice = 0;

        #region Construtores

        public Cadastro()
        {
            InitializeComponent();
        }

        public Cadastro(CadastroClientes cl)
        {
            InitializeComponent();

            ListarCampos(cl);
        }

        #endregion

        private void Cadastro_Load(object sender, EventArgs e)
        {
            using (ServiceReference1.Service1Client WCF_Listar = new ServiceReference1.Service1Client())
            {

                //dgvClientes.DataSource = WCF_Cadastro.ListarClientes();

                //Via List
                dgvClientes.DataSource = WCF_Listar.ListarCliente();
                OrdenarGrid();
                dgvClientes.Columns["Tipo"].Visible = false;
            }
        }

        #region Eventos

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            if (txtCodigo.Text == string.Empty)
            {
                if (validarCampos())
                {
                    using (ServiceReference1.Service1Client WCF_Cadastro = new ServiceReference1.Service1Client())
                    {
                        //não faz
                        //List<CadastroClientes> lista = new List<CadastroClientes>();

                        CadastroClientes clientes = new CadastroClientes();

                        clientes.Nome = txtNome.Text;
                        clientes.RG = txtRg.Text;
                        clientes.CPF = mkdCPF.Text;
                        clientes.Data_Nascimento = Convert.ToDateTime(dtpDataNascimento.Text);
                        clientes.Sexo = (rbtMasculino.Checked) ? 'M' : 'F';
                        clientes.Estado_Civil = cmbEstadoCivil.SelectedItem.ToString();

                        if (mkdTelefoneRes.Text.Replace("(", "").Replace(")", "").Replace("-", "").Replace(" ", "").Trim() == string.Empty)
                        {
                            clientes.Telefone_Res = "";
                        }

                        else
                        {
                            clientes.Telefone_Res = mkdTelefoneRes.Text;
                        }

                        if (mkdTelefoneCom.Text.Replace("(", "").Replace(")", "").Replace("-", "").Replace(" ", "").Trim() == string.Empty)
                        {
                            clientes.Telefone_Com = "";
                        }

                        else
                        {
                            clientes.Telefone_Com = mkdTelefoneCom.Text;
                        }

                        if (mkdCelular.Text.Replace("(", "").Replace(")", "").Replace("-", "").Replace(" ", "").Trim() == string.Empty)
                        {

                            clientes.Celular = "";
                        }

                        else
                        {
                            clientes.Celular = mkdCelular.Text;
                        }

                        clientes.Cidade = txtCidade.Text;
                        clientes.Estado = cmbEstado.SelectedItem.ToString();
                        clientes.Cep = mkdCep.Text;
                        clientes.Endereco = txtEndereco.Text;
                        clientes.Endereco_Numero = txtNumeroEndereco.Text;

                        if (string.IsNullOrEmpty(txtComplemento.Text))
                        {
                            clientes.Complemento = "";
                        }
                        else
                        {
                            clientes.Complemento = txtComplemento.Text;
                        }

                        clientes.Bairro = txtBairro.Text;
                        clientes.Email = txtEmail.Text;
                        clientes.Observacoes = txtObservacoes.Text;


                        //lista.Add(clientes);

                        // não manda lista quando somente uma linha
                        //WCF_Cadastro.IncluirClientes(lista);

                        WCF_Cadastro.IncluirCliente(clientes);

                        //Via List
                        dgvClientes.DataSource = WCF_Cadastro.ListarCliente();
                        //dgvClientes.Columns["ID"].Visible = false;

                        LimparTexto();
                        OrdenarGrid();
                    }
                }
            }

            else
            {

                MessageBox.Show("Cadastro não efetuado, favor preencher um cadastro em branco", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                LimparTexto();
            }
        }

        private void btnAtualizar_Click(object sender, EventArgs e)
        {
            if (validarCampos())
            {
                using (ServiceReference1.Service1Client WCF_Cadastro = new ServiceReference1.Service1Client())
                {

                    CadastroClientes cliente = new CadastroClientes();

                    DataGridViewRow rowData = dgvClientes.Rows[_linhaIndice];

                    cliente.ID_Cliente = Convert.ToInt32(txtCodigo.Text); //Convert.ToInt32(rowData.Cells["ID"].Value);
                    cliente.Nome = txtNome.Text;
                    cliente.Data_Cadastro = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss"));
                    cliente.RG = txtRg.Text;
                    cliente.CPF = mkdCPF.Text;
                    cliente.Data_Nascimento = Convert.ToDateTime(dtpDataNascimento.Text);
                    if (rbtMasculino.Checked == true) { cliente.Sexo = 'M'; } else { cliente.Sexo = 'F'; }
                    cliente.Estado_Civil = cmbEstadoCivil.SelectedItem.ToString();

                    if (mkdTelefoneRes.Text.Replace("(", "").Replace(")", "").Replace("-", "").Replace(" ", "").Trim() == string.Empty)
                    {
                        cliente.Telefone_Res = "";
                    }

                    else
                    {
                        cliente.Telefone_Res = mkdTelefoneRes.Text;
                    }

                    if (mkdTelefoneCom.Text.Replace("(", "").Replace(")", "").Replace("-", "").Replace(" ", "").Trim() == string.Empty)
                    {
                        cliente.Telefone_Com = "";
                    }

                    else
                    {
                        cliente.Telefone_Com = mkdTelefoneCom.Text;
                    }

                    if (mkdCelular.Text.Replace("(", "").Replace(")", "").Replace("-", "").Replace(" ", "").Trim() == string.Empty)
                    {

                        cliente.Celular = "";
                    }

                    else
                    {
                        cliente.Celular = mkdCelular.Text;
                    }

                    cliente.Cidade = txtCidade.Text;
                    cliente.Estado = cmbEstado.SelectedItem.ToString();
                    cliente.Cep = mkdCep.Text;
                    cliente.Endereco = txtEndereco.Text;
                    cliente.Endereco_Numero = txtNumeroEndereco.Text;

                    if (string.IsNullOrEmpty(txtComplemento.Text))
                    {
                        cliente.Complemento = "";
                    }

                    else
                    {
                        cliente.Complemento = txtComplemento.Text;
                    }

                    cliente.Bairro = txtBairro.Text;
                    cliente.Email = txtEmail.Text;
                    cliente.Observacoes = txtObservacoes.Text;

                    WCF_Cadastro.AtualizarClientes(cliente);

                    //dgvClientes.DataSource = WCF_Cadastro.ListarClientes();

                    //Via List
                    dgvClientes.DataSource = WCF_Cadastro.ListarCliente();
                    dgvClientes.Columns["Tipo"].Visible = false;
                    OrdenarGrid();
                    LimparTexto();
                }
            }
        }

        private void btnDeletar_Click(object sender, EventArgs e)
        {
            if (txtCodigo.Text != "")
            {
                if (MessageBox.Show("Deseja realmente remover o cliente selecionado?", "Atenção", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    using (ServiceReference1.Service1Client WCF_Cadastro = new ServiceReference1.Service1Client())
                    {
                        CadastroClientes clientes = new CadastroClientes();

                        DataGridViewRow rowData = dgvClientes.Rows[_linhaIndice];

                        clientes.ID_Cliente = Convert.ToInt32(rowData.Cells["ID_CLIENTE"].Value);

                        WCF_Cadastro.DeletarClientes(clientes.ID_Cliente);

                        //dgvClientes.DataSource = WCF_Cadastro.ListarClientes();

                        //Via List
                        dgvClientes.DataSource = WCF_Cadastro.ListarCliente();
                        //dgvClientes.Columns["ID"].Visible = false;

                        LimparTexto();
                    }
                }
            }

            else
            {
                MessageBox.Show("Favor selecionar um item da tabela", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }


        /// <summary>
        /// Eventos disparado quando um item é selecionado no Grid
        /// </summary>
        private void dgvClientes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //Retorna o indice da linha no qual a célula foi clicada
            _linhaIndice = e.RowIndex;

            //Se _linhaIndice é menor que -1 então retorna
            if (_linhaIndice == -1)
            {
                return;
            }

            //Cria um objeto DataGridViewRow de um indice particular
            DataGridViewRow rowData = dgvClientes.Rows[_linhaIndice];

            CadastroClientes cl = (CadastroClientes)dgvClientes.Rows[_linhaIndice].DataBoundItem;

            //exibe os valores no textbox

            //como era feito
            //txtNome.Text = rowData.Cells["Nome"].Value.ToString();
            txtCodigo.Text = cl.ID_Cliente.ToString();
            txtNome.Text = cl.Nome.ToString();
            txtDataCadastro.Text = cl.Data_Cadastro.ToString();
            txtRg.Text = cl.RG.ToString();
            mkdCPF.Text = cl.CPF.ToString();
            dtpDataNascimento.Text = cl.Data_Nascimento.ToString();
            if ((cl.Sexo.ToString() == "M") ? rbtMasculino.Checked = true : rbtFeminino.Checked = true)
                cmbEstadoCivil.Text = cl.Estado_Civil.ToString();
            mkdTelefoneRes.Text = cl.DDD_Res.ToString().Trim() + cl.Telefone_Res.ToString().Trim();
            mkdTelefoneCom.Text = cl.DDD_Com.ToString().Trim() + cl.Telefone_Com.ToString();
            mkdCelular.Text = cl.DDD_Cel.ToString().Trim() + cl.Celular.ToString();
            txtCidade.Text = cl.Cidade.ToString();
            cmbEstado.Text = cl.Estado.ToString();
            mkdCep.Text = cl.Cep.ToString();
            txtEndereco.Text = cl.Endereco.ToString();
            txtNumeroEndereco.Text = cl.Endereco_Numero.ToString();
            txtComplemento.Text = cl.Complemento.ToString();
            txtBairro.Text = cl.Bairro.ToString();
            txtEmail.Text = cl.Email.ToString();
            txtObservacoes.Text = cl.Observacoes.ToString();

            errorProvider1.Clear();
        }


        /// <summary>
        /// Eventos disparado para chamar outro Form
        /// </summary>
        private void btnConsultaClientes_Click(object sender, EventArgs e)
        {
            //if (Application.OpenForms.OfType<ConsultaClientes>().Count() > 0)
            //{
            //    MessageBox.Show("A tela Consulta de Clientes já está aberta!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
            //else
            //{
            //    ConsultaClientes consulta = new ConsultaClientes();
            //    consulta.Show();
            //}

            //ConsultaClientes consulta = new ConsultaClientes();
            //consulta.ShowDialog();
            //consulta.Close();
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && !(e.KeyChar == (char)Keys.Back) && !(e.KeyChar == (char)Keys.Space))
            {
                e.Handled = true;
            }
        }

        private void mkdDataNascimento_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtCidade_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        #endregion

        #region Métodos

        private void ListarCampos(CadastroClientes cl)
        {
            txtCodigo.Text = cl.ID_Cliente.ToString();
            txtNome.Text = cl.Nome.ToString();
            txtDataCadastro.Text = cl.Data_Cadastro.ToString();
            txtRg.Text = cl.RG.ToString();
            mkdCPF.Text = cl.CPF.ToString();
            dtpDataNascimento.Text = cl.Data_Nascimento.ToString();
            if ((cl.Sexo.ToString() == "M") ? rbtMasculino.Checked = true : rbtFeminino.Checked = true)
                cmbEstadoCivil.Text = cl.Estado_Civil.ToString();
            mkdTelefoneRes.Text = cl.DDD_Res.ToString().Trim() + cl.Telefone_Res.ToString().Trim();
            mkdTelefoneCom.Text = cl.DDD_Com.ToString().Trim() + cl.Telefone_Com.ToString();
            mkdCelular.Text = cl.DDD_Cel.ToString().Trim() + cl.Celular.ToString();
            txtCidade.Text = cl.Cidade.ToString();
            cmbEstado.Text = cl.Estado.ToString();
            mkdCep.Text = cl.Cep.ToString();
            txtEndereco.Text = cl.Endereco.ToString();
            txtNumeroEndereco.Text = cl.Endereco_Numero.ToString();
            txtComplemento.Text = cl.Complemento.ToString();
            txtBairro.Text = cl.Bairro.ToString();
            txtEmail.Text = cl.Email.ToString();
            txtObservacoes.Text = cl.Observacoes.ToString();
        }

        private void LimparTexto()
        {           
            foreach (Control controle in this.Controls)
            {
                if (controle.GetType() == typeof(TextBox) || controle.GetType() == typeof(MaskedTextBox)
                   || controle.GetType() == typeof(DateTimePicker))
                {
                    controle.Text = "";
                }
            }

            foreach (RadioButton radio in this.Controls.OfType<RadioButton>())
            {
                if (radio.GetType() == typeof(RadioButton))
                {
                    radio.Checked = false;
                }
            }

            foreach (ComboBox cmb in this.Controls.OfType<ComboBox>())
            {
                if (cmb.GetType() == typeof(ComboBox))
                {
                    cmb.SelectedIndex = -1;
                }
            }
        }


        private void OrdenarGrid()
        {
            this.dgvClientes.Columns["ID_CLIENTE"].DisplayIndex = 0;
            this.dgvClientes.Columns["NOME"].DisplayIndex = 1;
            this.dgvClientes.Columns["RG"].DisplayIndex = 2;
            this.dgvClientes.Columns["CPF"].DisplayIndex = 3;
            this.dgvClientes.Columns["DATA_NASCIMENTO"].DisplayIndex = 4;
            this.dgvClientes.Columns["SEXO"].DisplayIndex = 5;
            this.dgvClientes.Columns["ESTADO_CIVIL"].DisplayIndex = 6;
            this.dgvClientes.Columns["DDD_RES"].DisplayIndex = 7;
            this.dgvClientes.Columns["TELEFONE_Res"].DisplayIndex = 8;
            this.dgvClientes.Columns["DDD_COM"].DisplayIndex = 9;
            this.dgvClientes.Columns["TELEFONE_Com"].DisplayIndex = 10;
            this.dgvClientes.Columns["DDD_CEL"].DisplayIndex = 11;
            this.dgvClientes.Columns["CELULAR"].DisplayIndex = 12;
            this.dgvClientes.Columns["CIDADE"].DisplayIndex = 13;
            this.dgvClientes.Columns["ESTADO"].DisplayIndex = 14;
            this.dgvClientes.Columns["CEP"].DisplayIndex = 15;
            this.dgvClientes.Columns["ENDERECO"].DisplayIndex = 16;
            this.dgvClientes.Columns["ENDERECO_NUMERO"].DisplayIndex = 17;
            this.dgvClientes.Columns["COMPLEMENTO"].DisplayIndex = 18;
            this.dgvClientes.Columns["BAIRRO"].DisplayIndex = 19;
            this.dgvClientes.Columns["EMAIL"].DisplayIndex = 20;
            this.dgvClientes.Columns["DATA_CADASTRO"].DisplayIndex = 21;
            this.dgvClientes.Columns["DATA_ALTERACAO"].DisplayIndex = 22;
            this.dgvClientes.Columns["OBSERVACOES"].DisplayIndex = 23;
        }
        #endregion

        #region Validadores
        private Boolean validarCampos()
        {
            bool validar = true;

            errorProvider1.Clear();

            if (txtNome.Text == string.Empty)
            {
                errorProvider1.SetError(txtNome, "Dados Obrigatórios");
                validar = false;
            }
            if (txtRg.Text == string.Empty)
            {
                errorProvider1.SetError(txtRg, "Dados Obrigatórios");
                validar = false;
            }
            if (!mkdCPF.MaskCompleted)
            {
                errorProvider1.SetError(mkdCPF, "Dados Obrigatórios");
                validar = false;
            }

            if (!rbtMasculino.Checked && !rbtFeminino.Checked)
            {
                errorProvider1.SetError(rbtFeminino, "Dados Obrigatórios");
                validar = false;
            }

            if (cmbEstadoCivil.SelectedItem == null)
            {
                errorProvider1.SetError(cmbEstadoCivil, "Dados Obrigatórios");
                validar = false;
            }

            if (mkdTelefoneRes.Text.Replace("(", "").Replace(")", "").Replace("-", "").Replace(" ", "").Trim() != string.Empty)
            {
                string validaTelefoneRes = @"^\(\d{2}\)\d{4}-\d{4}$";

                Regex re = new Regex(validaTelefoneRes);

                if (!re.IsMatch(mkdTelefoneRes.Text.Replace(" ", "").Trim()))
                {
                    errorProvider1.SetError(mkdTelefoneRes, "Telefone Incorreto");
                    validar = false;
                }
            }

            if (mkdTelefoneCom.Text.Replace("(", "").Replace(")", "").Replace("-", "").Replace(" ", "").Trim() != string.Empty)
            {
                string validaTelefoneCom = @"^\(\d{2}\)\d{4}-\d{4}$";

                Regex re = new Regex(validaTelefoneCom);

                if (!re.IsMatch(mkdTelefoneCom.Text.Replace(" ", "").Trim()))
                {
                    errorProvider1.SetError(mkdTelefoneCom, "Telefone Incorreto");
                    validar = false;
                }
            }

            if (txtCidade.Text == string.Empty)
            {
                errorProvider1.SetError(txtCidade, "Dados Obrigatórios");
                validar = false;
            }

            if (cmbEstado.SelectedItem == null)
            {
                errorProvider1.SetError(cmbEstado, "Dados Obrigatórios");
                validar = false;
            }

            if (!mkdCep.MaskCompleted)
            {
                errorProvider1.SetError(mkdCep, "Dados Obrigatórios");
                validar = false;
            }

            if (txtEndereco.Text == string.Empty)
            {
                errorProvider1.SetError(txtEndereco, "Dados Obrigatórios");
                validar = false;
            }

            if (txtNumeroEndereco.Text == string.Empty)
            {
                errorProvider1.SetError(txtNumeroEndereco, "Dados Obrigatórios");
                validar = false;
            }

            if (txtBairro.Text == string.Empty)
            {
                errorProvider1.SetError(txtBairro, "Dados Obrigatórios");
                validar = false;
            }            

            if (txtEmail.Text != "")
            {
                string validaEmail = @"^(?!\.)(""([^""\r\\]|\\[""\r\\])*""|"
                                    + @"([-a-z0-9!#$%&'*+/=?^_`{|}~]|(?<!\.)\.)*)(?<!\.)"
                                    + @"@[a-z0-9][\w\.-]*[a-z0-9]\.[a-z][a-z\.]*[a-z]$";

                Regex re = new Regex(validaEmail);

                if (!re.IsMatch(txtEmail.Text))
                {
                    errorProvider1.SetError(txtEmail, "Email Incorreto");
                    validar = false;
                }
            }

            return validar;
        }

        #endregion

        private void btnLimparFormulario_Click(object sender, EventArgs e)
        {
            LimparTexto();
        }
    }
}
