﻿namespace CadastroDeClientes
{
    partial class Cadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnLimparFormulario = new System.Windows.Forms.Button();
            this.dtpDataNascimento = new System.Windows.Forms.DateTimePicker();
            this.txtObservacoes = new System.Windows.Forms.TextBox();
            this.lblObservacoes = new System.Windows.Forms.Label();
            this.btnDeletar = new System.Windows.Forms.Button();
            this.txtBairro = new System.Windows.Forms.TextBox();
            this.btnAtualizar = new System.Windows.Forms.Button();
            this.mkdCelular = new System.Windows.Forms.MaskedTextBox();
            this.dgvClientes = new System.Windows.Forms.DataGridView();
            this.rbtFeminino = new System.Windows.Forms.RadioButton();
            this.btnCadastrar = new System.Windows.Forms.Button();
            this.txtComplemento = new System.Windows.Forms.TextBox();
            this.rbtMasculino = new System.Windows.Forms.RadioButton();
            this.lblSexo = new System.Windows.Forms.Label();
            this.txtRg = new System.Windows.Forms.TextBox();
            this.txtDataCadastro = new System.Windows.Forms.TextBox();
            this.txtEndereco = new System.Windows.Forms.TextBox();
            this.lblDataCadastro = new System.Windows.Forms.Label();
            this.lblDataNascimento = new System.Windows.Forms.Label();
            this.txtCodigo = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblCodigo = new System.Windows.Forms.Label();
            this.lblTelefone = new System.Windows.Forms.Label();
            this.lblCelular = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.cmbEstadoCivil = new System.Windows.Forms.ComboBox();
            this.lblEndereco = new System.Windows.Forms.Label();
            this.lblEstadoCivil = new System.Windows.Forms.Label();
            this.lblCPF = new System.Windows.Forms.Label();
            this.mkdTelefoneCom = new System.Windows.Forms.MaskedTextBox();
            this.lblTelefoneComercial = new System.Windows.Forms.Label();
            this.lblRG = new System.Windows.Forms.Label();
            this.lblBairro = new System.Windows.Forms.Label();
            this.mkdTelefoneRes = new System.Windows.Forms.MaskedTextBox();
            this.cmbEstado = new System.Windows.Forms.ComboBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblEstado = new System.Windows.Forms.Label();
            this.mkdCPF = new System.Windows.Forms.MaskedTextBox();
            this.txtCidade = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblCidade = new System.Windows.Forms.Label();
            this.lblNumeroEndereco = new System.Windows.Forms.Label();
            this.mkdCep = new System.Windows.Forms.MaskedTextBox();
            this.txtNumeroEndereco = new System.Windows.Forms.TextBox();
            this.lblCEP = new System.Windows.Forms.Label();
            this.lblComplemento = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLimparFormulario
            // 
            this.btnLimparFormulario.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnLimparFormulario.Location = new System.Drawing.Point(474, 599);
            this.btnLimparFormulario.Name = "btnLimparFormulario";
            this.btnLimparFormulario.Size = new System.Drawing.Size(102, 23);
            this.btnLimparFormulario.TabIndex = 150;
            this.btnLimparFormulario.Text = "Limpar Formulário";
            this.btnLimparFormulario.UseVisualStyleBackColor = true;
            this.btnLimparFormulario.Click += new System.EventHandler(this.btnLimparFormulario_Click);
            // 
            // dtpDataNascimento
            // 
            this.dtpDataNascimento.CustomFormat = "dd/MM/yyyy";
            this.dtpDataNascimento.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpDataNascimento.Location = new System.Drawing.Point(315, 94);
            this.dtpDataNascimento.Name = "dtpDataNascimento";
            this.dtpDataNascimento.Size = new System.Drawing.Size(101, 20);
            this.dtpDataNascimento.TabIndex = 108;
            this.dtpDataNascimento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mkdDataNascimento_KeyPress);
            // 
            // txtObservacoes
            // 
            this.txtObservacoes.Location = new System.Drawing.Point(57, 347);
            this.txtObservacoes.Multiline = true;
            this.txtObservacoes.Name = "txtObservacoes";
            this.txtObservacoes.Size = new System.Drawing.Size(484, 56);
            this.txtObservacoes.TabIndex = 123;
            // 
            // lblObservacoes
            // 
            this.lblObservacoes.AutoSize = true;
            this.lblObservacoes.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblObservacoes.Location = new System.Drawing.Point(56, 331);
            this.lblObservacoes.Name = "lblObservacoes";
            this.lblObservacoes.Size = new System.Drawing.Size(70, 13);
            this.lblObservacoes.TabIndex = 149;
            this.lblObservacoes.Text = "Observações";
            // 
            // btnDeletar
            // 
            this.btnDeletar.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnDeletar.Location = new System.Drawing.Point(336, 599);
            this.btnDeletar.Name = "btnDeletar";
            this.btnDeletar.Size = new System.Drawing.Size(75, 23);
            this.btnDeletar.TabIndex = 134;
            this.btnDeletar.Text = "Deletar";
            this.btnDeletar.UseVisualStyleBackColor = true;
            this.btnDeletar.Click += new System.EventHandler(this.btnDeletar_Click);
            // 
            // txtBairro
            // 
            this.txtBairro.Location = new System.Drawing.Point(57, 300);
            this.txtBairro.Name = "txtBairro";
            this.txtBairro.Size = new System.Drawing.Size(177, 20);
            this.txtBairro.TabIndex = 121;
            // 
            // btnAtualizar
            // 
            this.btnAtualizar.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnAtualizar.Location = new System.Drawing.Point(251, 599);
            this.btnAtualizar.Name = "btnAtualizar";
            this.btnAtualizar.Size = new System.Drawing.Size(75, 23);
            this.btnAtualizar.TabIndex = 133;
            this.btnAtualizar.Text = "Atualizar";
            this.btnAtualizar.UseVisualStyleBackColor = true;
            this.btnAtualizar.Click += new System.EventHandler(this.btnAtualizar_Click);
            // 
            // mkdCelular
            // 
            this.mkdCelular.Location = new System.Drawing.Point(438, 144);
            this.mkdCelular.Mask = "(99) 99999-9999";
            this.mkdCelular.Name = "mkdCelular";
            this.mkdCelular.Size = new System.Drawing.Size(110, 20);
            this.mkdCelular.TabIndex = 114;
            // 
            // dgvClientes
            // 
            this.dgvClientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvClientes.Location = new System.Drawing.Point(25, 432);
            this.dgvClientes.Name = "dgvClientes";
            this.dgvClientes.Size = new System.Drawing.Size(551, 131);
            this.dgvClientes.TabIndex = 132;
            this.dgvClientes.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvClientes_CellClick);
            // 
            // rbtFeminino
            // 
            this.rbtFeminino.AutoSize = true;
            this.rbtFeminino.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.rbtFeminino.Location = new System.Drawing.Point(517, 97);
            this.rbtFeminino.Name = "rbtFeminino";
            this.rbtFeminino.Size = new System.Drawing.Size(67, 17);
            this.rbtFeminino.TabIndex = 110;
            this.rbtFeminino.TabStop = true;
            this.rbtFeminino.Text = "Feminino";
            this.rbtFeminino.UseVisualStyleBackColor = true;
            // 
            // btnCadastrar
            // 
            this.btnCadastrar.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnCadastrar.Location = new System.Drawing.Point(159, 599);
            this.btnCadastrar.Name = "btnCadastrar";
            this.btnCadastrar.Size = new System.Drawing.Size(75, 23);
            this.btnCadastrar.TabIndex = 128;
            this.btnCadastrar.Text = "Cadastrar";
            this.btnCadastrar.UseVisualStyleBackColor = true;
            this.btnCadastrar.Click += new System.EventHandler(this.btnCadastrar_Click);
            // 
            // txtComplemento
            // 
            this.txtComplemento.Location = new System.Drawing.Point(399, 249);
            this.txtComplemento.Name = "txtComplemento";
            this.txtComplemento.Size = new System.Drawing.Size(166, 20);
            this.txtComplemento.TabIndex = 120;
            // 
            // rbtMasculino
            // 
            this.rbtMasculino.AutoSize = true;
            this.rbtMasculino.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.rbtMasculino.Location = new System.Drawing.Point(438, 97);
            this.rbtMasculino.Name = "rbtMasculino";
            this.rbtMasculino.Size = new System.Drawing.Size(73, 17);
            this.rbtMasculino.TabIndex = 109;
            this.rbtMasculino.TabStop = true;
            this.rbtMasculino.Text = "Masculino";
            this.rbtMasculino.UseVisualStyleBackColor = true;
            // 
            // lblSexo
            // 
            this.lblSexo.AutoSize = true;
            this.lblSexo.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblSexo.Location = new System.Drawing.Point(435, 79);
            this.lblSexo.Name = "lblSexo";
            this.lblSexo.Size = new System.Drawing.Size(31, 13);
            this.lblSexo.TabIndex = 148;
            this.lblSexo.Text = "Sexo";
            // 
            // txtRg
            // 
            this.txtRg.Location = new System.Drawing.Point(53, 94);
            this.txtRg.Name = "txtRg";
            this.txtRg.Size = new System.Drawing.Size(134, 20);
            this.txtRg.TabIndex = 106;
            // 
            // txtDataCadastro
            // 
            this.txtDataCadastro.Enabled = false;
            this.txtDataCadastro.Location = new System.Drawing.Point(451, 44);
            this.txtDataCadastro.Name = "txtDataCadastro";
            this.txtDataCadastro.Size = new System.Drawing.Size(114, 20);
            this.txtDataCadastro.TabIndex = 147;
            // 
            // txtEndereco
            // 
            this.txtEndereco.Location = new System.Drawing.Point(53, 249);
            this.txtEndereco.Name = "txtEndereco";
            this.txtEndereco.Size = new System.Drawing.Size(261, 20);
            this.txtEndereco.TabIndex = 118;
            // 
            // lblDataCadastro
            // 
            this.lblDataCadastro.AutoSize = true;
            this.lblDataCadastro.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblDataCadastro.Location = new System.Drawing.Point(451, 28);
            this.lblDataCadastro.Name = "lblDataCadastro";
            this.lblDataCadastro.Size = new System.Drawing.Size(90, 13);
            this.lblDataCadastro.TabIndex = 146;
            this.lblDataCadastro.Text = "Data de Cadastro";
            // 
            // lblDataNascimento
            // 
            this.lblDataNascimento.AutoSize = true;
            this.lblDataNascimento.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblDataNascimento.Location = new System.Drawing.Point(315, 77);
            this.lblDataNascimento.Name = "lblDataNascimento";
            this.lblDataNascimento.Size = new System.Drawing.Size(89, 13);
            this.lblDataNascimento.TabIndex = 131;
            this.lblDataNascimento.Text = "Data Nascimento";
            // 
            // txtCodigo
            // 
            this.txtCodigo.Enabled = false;
            this.txtCodigo.Location = new System.Drawing.Point(53, 44);
            this.txtCodigo.Name = "txtCodigo";
            this.txtCodigo.Size = new System.Drawing.Size(75, 20);
            this.txtCodigo.TabIndex = 145;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(254, 300);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(299, 20);
            this.txtEmail.TabIndex = 122;
            // 
            // lblCodigo
            // 
            this.lblCodigo.AutoSize = true;
            this.lblCodigo.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCodigo.Location = new System.Drawing.Point(54, 28);
            this.lblCodigo.Name = "lblCodigo";
            this.lblCodigo.Size = new System.Drawing.Size(40, 13);
            this.lblCodigo.TabIndex = 144;
            this.lblCodigo.Text = "Código";
            // 
            // lblTelefone
            // 
            this.lblTelefone.AutoSize = true;
            this.lblTelefone.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTelefone.Location = new System.Drawing.Point(166, 128);
            this.lblTelefone.Name = "lblTelefone";
            this.lblTelefone.Size = new System.Drawing.Size(107, 13);
            this.lblTelefone.TabIndex = 130;
            this.lblTelefone.Text = "Telefone Residencial";
            // 
            // lblCelular
            // 
            this.lblCelular.AutoSize = true;
            this.lblCelular.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCelular.Location = new System.Drawing.Point(435, 128);
            this.lblCelular.Name = "lblCelular";
            this.lblCelular.Size = new System.Drawing.Size(39, 13);
            this.lblCelular.TabIndex = 143;
            this.lblCelular.Text = "Celular";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblEmail.Location = new System.Drawing.Point(251, 284);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(32, 13);
            this.lblEmail.TabIndex = 129;
            this.lblEmail.Text = "Email";
            // 
            // cmbEstadoCivil
            // 
            this.cmbEstadoCivil.DisplayMember = "\"\"";
            this.cmbEstadoCivil.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEstadoCivil.FormattingEnabled = true;
            this.cmbEstadoCivil.Items.AddRange(new object[] {
            "Solteiro(a)",
            "Casado(a)",
            "Viúvo(a)",
            "Divociado(a)"});
            this.cmbEstadoCivil.Location = new System.Drawing.Point(53, 144);
            this.cmbEstadoCivil.Name = "cmbEstadoCivil";
            this.cmbEstadoCivil.Size = new System.Drawing.Size(94, 21);
            this.cmbEstadoCivil.TabIndex = 111;
            // 
            // lblEndereco
            // 
            this.lblEndereco.AutoSize = true;
            this.lblEndereco.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblEndereco.Location = new System.Drawing.Point(54, 233);
            this.lblEndereco.Name = "lblEndereco";
            this.lblEndereco.Size = new System.Drawing.Size(53, 13);
            this.lblEndereco.TabIndex = 127;
            this.lblEndereco.Text = "Endereço";
            // 
            // lblEstadoCivil
            // 
            this.lblEstadoCivil.AutoSize = true;
            this.lblEstadoCivil.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblEstadoCivil.Location = new System.Drawing.Point(50, 128);
            this.lblEstadoCivil.Name = "lblEstadoCivil";
            this.lblEstadoCivil.Size = new System.Drawing.Size(64, 13);
            this.lblEstadoCivil.TabIndex = 142;
            this.lblEstadoCivil.Text = "Estado Cívil";
            // 
            // lblCPF
            // 
            this.lblCPF.AutoSize = true;
            this.lblCPF.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCPF.Location = new System.Drawing.Point(200, 78);
            this.lblCPF.Name = "lblCPF";
            this.lblCPF.Size = new System.Drawing.Size(27, 13);
            this.lblCPF.TabIndex = 126;
            this.lblCPF.Text = "CPF";
            // 
            // mkdTelefoneCom
            // 
            this.mkdTelefoneCom.Location = new System.Drawing.Point(309, 145);
            this.mkdTelefoneCom.Mask = "(99) 9999-9999";
            this.mkdTelefoneCom.Name = "mkdTelefoneCom";
            this.mkdTelefoneCom.Size = new System.Drawing.Size(110, 20);
            this.mkdTelefoneCom.TabIndex = 113;
            // 
            // lblTelefoneComercial
            // 
            this.lblTelefoneComercial.AutoSize = true;
            this.lblTelefoneComercial.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblTelefoneComercial.Location = new System.Drawing.Point(306, 128);
            this.lblTelefoneComercial.Name = "lblTelefoneComercial";
            this.lblTelefoneComercial.Size = new System.Drawing.Size(98, 13);
            this.lblTelefoneComercial.TabIndex = 141;
            this.lblTelefoneComercial.Text = "Telefone Comercial";
            // 
            // lblRG
            // 
            this.lblRG.AutoSize = true;
            this.lblRG.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblRG.Location = new System.Drawing.Point(54, 78);
            this.lblRG.Name = "lblRG";
            this.lblRG.Size = new System.Drawing.Size(23, 13);
            this.lblRG.TabIndex = 125;
            this.lblRG.Text = "RG";
            // 
            // lblBairro
            // 
            this.lblBairro.AutoSize = true;
            this.lblBairro.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblBairro.Location = new System.Drawing.Point(54, 284);
            this.lblBairro.Name = "lblBairro";
            this.lblBairro.Size = new System.Drawing.Size(34, 13);
            this.lblBairro.TabIndex = 140;
            this.lblBairro.Text = "Bairro";
            // 
            // mkdTelefoneRes
            // 
            this.mkdTelefoneRes.Location = new System.Drawing.Point(169, 145);
            this.mkdTelefoneRes.Mask = "(99) 9999-9999";
            this.mkdTelefoneRes.Name = "mkdTelefoneRes";
            this.mkdTelefoneRes.Size = new System.Drawing.Size(110, 20);
            this.mkdTelefoneRes.TabIndex = 112;
            // 
            // cmbEstado
            // 
            this.cmbEstado.BackColor = System.Drawing.SystemColors.Window;
            this.cmbEstado.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEstado.FormattingEnabled = true;
            this.cmbEstado.Items.AddRange(new object[] {
            "AC",
            "AL",
            "AM",
            "AP",
            "BA",
            "CE",
            "DF",
            "ES",
            "FN",
            "GO",
            "MA",
            "MG",
            "MS",
            "MT",
            "PA",
            "PB",
            "PE",
            "PI",
            "PR",
            "RJ",
            "RN",
            "RO",
            "RR",
            "RS",
            "SC",
            "SE",
            "SP",
            "TO"});
            this.cmbEstado.Location = new System.Drawing.Point(254, 200);
            this.cmbEstado.Name = "cmbEstado";
            this.cmbEstado.Size = new System.Drawing.Size(39, 21);
            this.cmbEstado.TabIndex = 116;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblNome.Location = new System.Drawing.Point(131, 28);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 124;
            this.lblNome.Text = "Nome";
            // 
            // lblEstado
            // 
            this.lblEstado.AutoSize = true;
            this.lblEstado.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblEstado.Location = new System.Drawing.Point(256, 184);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(40, 13);
            this.lblEstado.TabIndex = 139;
            this.lblEstado.Text = "Estado";
            // 
            // mkdCPF
            // 
            this.mkdCPF.Location = new System.Drawing.Point(203, 94);
            this.mkdCPF.Mask = "000,000,000-00";
            this.mkdCPF.Name = "mkdCPF";
            this.mkdCPF.Size = new System.Drawing.Size(100, 20);
            this.mkdCPF.TabIndex = 107;
            // 
            // txtCidade
            // 
            this.txtCidade.Location = new System.Drawing.Point(53, 201);
            this.txtCidade.Name = "txtCidade";
            this.txtCidade.Size = new System.Drawing.Size(177, 20);
            this.txtCidade.TabIndex = 115;
            this.txtCidade.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCidade_KeyPress);
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(134, 44);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(300, 20);
            this.txtNome.TabIndex = 105;
            this.txtNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNome_KeyPress);
            // 
            // lblCidade
            // 
            this.lblCidade.AutoSize = true;
            this.lblCidade.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCidade.Location = new System.Drawing.Point(54, 185);
            this.lblCidade.Name = "lblCidade";
            this.lblCidade.Size = new System.Drawing.Size(40, 13);
            this.lblCidade.TabIndex = 138;
            this.lblCidade.Text = "Cidade";
            // 
            // lblNumeroEndereco
            // 
            this.lblNumeroEndereco.AutoSize = true;
            this.lblNumeroEndereco.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblNumeroEndereco.Location = new System.Drawing.Point(340, 234);
            this.lblNumeroEndereco.Name = "lblNumeroEndereco";
            this.lblNumeroEndereco.Size = new System.Drawing.Size(19, 13);
            this.lblNumeroEndereco.TabIndex = 135;
            this.lblNumeroEndereco.Text = "Nº";
            // 
            // mkdCep
            // 
            this.mkdCep.Location = new System.Drawing.Point(315, 201);
            this.mkdCep.Mask = "00000-000";
            this.mkdCep.Name = "mkdCep";
            this.mkdCep.Size = new System.Drawing.Size(135, 20);
            this.mkdCep.TabIndex = 117;
            // 
            // txtNumeroEndereco
            // 
            this.txtNumeroEndereco.Location = new System.Drawing.Point(340, 249);
            this.txtNumeroEndereco.Name = "txtNumeroEndereco";
            this.txtNumeroEndereco.Size = new System.Drawing.Size(37, 20);
            this.txtNumeroEndereco.TabIndex = 119;
            // 
            // lblCEP
            // 
            this.lblCEP.AutoSize = true;
            this.lblCEP.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblCEP.Location = new System.Drawing.Point(312, 184);
            this.lblCEP.Name = "lblCEP";
            this.lblCEP.Size = new System.Drawing.Size(28, 13);
            this.lblCEP.TabIndex = 136;
            this.lblCEP.Text = "CEP";
            // 
            // lblComplemento
            // 
            this.lblComplemento.AutoSize = true;
            this.lblComplemento.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.lblComplemento.Location = new System.Drawing.Point(399, 233);
            this.lblComplemento.Name = "lblComplemento";
            this.lblComplemento.Size = new System.Drawing.Size(71, 13);
            this.lblComplemento.TabIndex = 137;
            this.lblComplemento.Text = "Complemento";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Cadastro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(607, 657);
            this.Controls.Add(this.btnLimparFormulario);
            this.Controls.Add(this.dtpDataNascimento);
            this.Controls.Add(this.txtObservacoes);
            this.Controls.Add(this.lblObservacoes);
            this.Controls.Add(this.btnDeletar);
            this.Controls.Add(this.txtBairro);
            this.Controls.Add(this.btnAtualizar);
            this.Controls.Add(this.mkdCelular);
            this.Controls.Add(this.dgvClientes);
            this.Controls.Add(this.rbtFeminino);
            this.Controls.Add(this.btnCadastrar);
            this.Controls.Add(this.txtComplemento);
            this.Controls.Add(this.rbtMasculino);
            this.Controls.Add(this.lblSexo);
            this.Controls.Add(this.txtRg);
            this.Controls.Add(this.txtDataCadastro);
            this.Controls.Add(this.txtEndereco);
            this.Controls.Add(this.lblDataCadastro);
            this.Controls.Add(this.lblDataNascimento);
            this.Controls.Add(this.txtCodigo);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.lblCodigo);
            this.Controls.Add(this.lblTelefone);
            this.Controls.Add(this.lblCelular);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.cmbEstadoCivil);
            this.Controls.Add(this.lblEndereco);
            this.Controls.Add(this.lblEstadoCivil);
            this.Controls.Add(this.lblCPF);
            this.Controls.Add(this.mkdTelefoneCom);
            this.Controls.Add(this.lblTelefoneComercial);
            this.Controls.Add(this.lblRG);
            this.Controls.Add(this.lblBairro);
            this.Controls.Add(this.mkdTelefoneRes);
            this.Controls.Add(this.cmbEstado);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblEstado);
            this.Controls.Add(this.mkdCPF);
            this.Controls.Add(this.txtCidade);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblCidade);
            this.Controls.Add(this.lblNumeroEndereco);
            this.Controls.Add(this.mkdCep);
            this.Controls.Add(this.txtNumeroEndereco);
            this.Controls.Add(this.lblCEP);
            this.Controls.Add(this.lblComplemento);
            this.Name = "Cadastro";
            this.Text = "Cadastro";
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLimparFormulario;
        private System.Windows.Forms.DateTimePicker dtpDataNascimento;
        private System.Windows.Forms.TextBox txtObservacoes;
        private System.Windows.Forms.Label lblObservacoes;
        private System.Windows.Forms.Button btnDeletar;
        private System.Windows.Forms.TextBox txtBairro;
        private System.Windows.Forms.Button btnAtualizar;
        private System.Windows.Forms.MaskedTextBox mkdCelular;
        private System.Windows.Forms.DataGridView dgvClientes;
        private System.Windows.Forms.RadioButton rbtFeminino;
        private System.Windows.Forms.Button btnCadastrar;
        private System.Windows.Forms.TextBox txtComplemento;
        private System.Windows.Forms.RadioButton rbtMasculino;
        private System.Windows.Forms.Label lblSexo;
        private System.Windows.Forms.TextBox txtRg;
        private System.Windows.Forms.TextBox txtDataCadastro;
        private System.Windows.Forms.TextBox txtEndereco;
        private System.Windows.Forms.Label lblDataCadastro;
        private System.Windows.Forms.Label lblDataNascimento;
        private System.Windows.Forms.TextBox txtCodigo;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblCodigo;
        private System.Windows.Forms.Label lblTelefone;
        private System.Windows.Forms.Label lblCelular;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.ComboBox cmbEstadoCivil;
        private System.Windows.Forms.Label lblEndereco;
        private System.Windows.Forms.Label lblEstadoCivil;
        private System.Windows.Forms.Label lblCPF;
        private System.Windows.Forms.MaskedTextBox mkdTelefoneCom;
        private System.Windows.Forms.Label lblTelefoneComercial;
        private System.Windows.Forms.Label lblRG;
        private System.Windows.Forms.Label lblBairro;
        private System.Windows.Forms.MaskedTextBox mkdTelefoneRes;
        private System.Windows.Forms.ComboBox cmbEstado;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblEstado;
        private System.Windows.Forms.MaskedTextBox mkdCPF;
        private System.Windows.Forms.TextBox txtCidade;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblCidade;
        private System.Windows.Forms.Label lblNumeroEndereco;
        private System.Windows.Forms.MaskedTextBox mkdCep;
        private System.Windows.Forms.TextBox txtNumeroEndereco;
        private System.Windows.Forms.Label lblCEP;
        private System.Windows.Forms.Label lblComplemento;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}