﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;

namespace WcfService1.VOL
{
        [DataContract]
        public class CadastroClientes
        {
            [DataMember]
            public int ID_Cliente { get; set; }

            [DataMember]
            public string Nome { get; set; }

            [DataMember]
            public string RG { get; set; }

            [DataMember]
            public string CPF { get; set; }

            [DataMember]
            public char Sexo { get; set; }

            [DataMember]
            public string Estado_Civil { get; set; }

            [DataMember]
            public string DDD_Res { get; set; }

            [DataMember]
            public string DDD_Com { get; set; }

            [DataMember]
            public string DDD_Cel { get; set; }

            [DataMember]
            public string Telefone_Res { get; set; }

            [DataMember]
            public string Telefone_Com { get; set; }

            [DataMember]
            public string Celular { get; set; }

            [DataMember]
            public string Tipo { get; set; }

            [DataMember]
            public string Endereco { get; set; }

            [DataMember]
            public string Endereco_Numero { get; set; }

            [DataMember]
            public string Complemento { get; set; }

            [DataMember]
            public string Bairro { get; set; }

            [DataMember]
            public string Cep { get; set; }

            [DataMember]
            public string Cidade { get; set; }

            [DataMember]
            public string Estado { get; set; }

            [DataMember]
            public DateTime Data_Nascimento { get; set; }

            [DataMember]
            public string Email { get; set; }

            [DataMember]
            public DateTime Data_Cadastro { get; set; }

            //Aceita valores nulos
            [DataMember]
            public DateTime? Data_Alteracao { get; set; }
            //public Nullable<DateTime> Data_Alteracao { get; set; }

            [DataMember]
            public string Observacoes { get; set; }
        }
    }