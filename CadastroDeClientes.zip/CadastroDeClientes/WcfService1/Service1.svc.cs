﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Text.RegularExpressions;
using System.Configuration;
using WcfService1.VOL;
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;

namespace WcfService1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        private SqlConnection cn;
        private SqlCommand cm;

        public Service1()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["Base2124"].ToString());

            cm = new SqlCommand();
            cm.Connection = cn;
        }

        public List<CadastroClientes> ListarCliente()
        {
            List<CadastroClientes> lista = new List<CadastroClientes>();

            cm.CommandText = "PROC_LISTAR_CLIENTES_TB_CLIENTES";
            cm.CommandType = CommandType.StoredProcedure;
            cm.CommandTimeout = 999999;

            cn.Open();

            SqlDataReader dr = cm.ExecuteReader();

            DataTable dt = new DataTable("Clientes");
            dt.Load(dr);

            foreach (DataRow r in dt.Rows)
            {

                CadastroClientes cl = new CadastroClientes();
                cl.ID_Cliente = Convert.ToInt32(r["ID_CLIENTE"]);
                cl.Nome = Convert.ToString(r["NOME"]);
                cl.RG = Convert.ToString(r["RG"]);
                cl.CPF = Convert.ToString(r["CPF"]);
                cl.Data_Nascimento = Convert.ToDateTime(r["DATA_NASCIMENTO"]);
                cl.Sexo = Convert.ToChar(r["SEXO"]);
                cl.Estado_Civil = Convert.ToString(r["ESTADO_CIVIL"]);
                cl.DDD_Res = Convert.ToString(r["DDD_RES"]);
                cl.Telefone_Res = Convert.ToString(r["TELEFONE_RES"]);
                cl.DDD_Com = Convert.ToString(r["DDD_COM"]);
                cl.Telefone_Com = Convert.ToString(r["TELEFONE_COM"]);
                cl.DDD_Cel = Convert.ToString(r["DDD_CEL"]);
                cl.Celular = Convert.ToString(r["CELULAR"]);
                cl.Cidade = Convert.ToString(r["CIDADE"]);
                cl.Estado = Convert.ToString(r["ESTADO"]);
                cl.Cep = Convert.ToString(r["CEP"]);
                cl.Endereco = Convert.ToString(r["ENDERECO"]);
                cl.Endereco_Numero = Convert.ToString(r["ENDERECO_NUMERO"]);
                cl.Complemento = Convert.ToString(r["COMPLEMENTO"]);
                cl.Bairro = Convert.ToString(r["BAIRRO"]);
                cl.Email = Convert.ToString(r["EMAIL"]);
                cl.Data_Cadastro = Convert.ToDateTime(r["DATA_CADASTRO"]);

                if ((r["DATA_ALTERACAO"]).ToString() == string.Empty)
                {
                    cl.Data_Alteracao = null;
                }

                else
                {
                    cl.Data_Alteracao = Convert.ToDateTime(r["DATA_ALTERACAO"]);
                }

                cl.Observacoes = Convert.ToString(r["OBSERVACOES"]);

                lista.Add(cl);
            }

            dr.Close();
            cn.Close();

            return lista;
        }
        public void IncluirCliente(CadastroClientes a)
        {

            cm.Parameters.Clear();

            cm.CommandText = "PROC_INSERIR_TB_CLIENTES";
            cm.CommandType = CommandType.StoredProcedure;
            cm.CommandTimeout = 999999;

            SqlParameter pNome = new SqlParameter();
            pNome.ParameterName = "@Nome";
            pNome.Value = a.Nome;
            pNome.DbType = System.Data.DbType.String;

            SqlParameter pRG = new SqlParameter();
            pRG.ParameterName = "@RG";
            pRG.Value = a.RG;
            pRG.DbType = System.Data.DbType.String;

            SqlParameter pCPF = new SqlParameter();
            pCPF.ParameterName = "@CPF";
            pCPF.Value = a.CPF;
            pCPF.DbType = System.Data.DbType.String;

            SqlParameter pDataNascimento = new SqlParameter();
            pDataNascimento.ParameterName = "@Data_Nascimento";
            pDataNascimento.Value = a.Data_Nascimento;
            pDataNascimento.DbType = System.Data.DbType.Date;

            SqlParameter pSexo = new SqlParameter();
            pSexo.ParameterName = "@Sexo";
            pSexo.Value = a.Sexo;
            pSexo.DbType = System.Data.DbType.String;

            SqlParameter pEstadoCivil = new SqlParameter();
            pEstadoCivil.ParameterName = "@Estado_Civil";
            pEstadoCivil.Value = a.Estado_Civil;
            pEstadoCivil.DbType = System.Data.DbType.String;

            SqlParameter pDDD_Res = new SqlParameter();
            pDDD_Res.ParameterName = "@DDD_Res";

            SqlParameter pTelefone_Res = new SqlParameter();
            pTelefone_Res.ParameterName = "@Telefone_Res";

            if (string.IsNullOrEmpty(a.Telefone_Res.ToString()))
            {
                pDDD_Res.Value = a.Telefone_Res;
                pDDD_Res.DbType = System.Data.DbType.String;

                pTelefone_Res.Value = a.Telefone_Res;
                pTelefone_Res.DbType = System.Data.DbType.String;
            }
            else
            {
                pDDD_Res.Value = a.Telefone_Res.Substring(1, 2);
                pDDD_Res.DbType = System.Data.DbType.String;

                pTelefone_Res.Value = a.Telefone_Res.Substring(5, 9);
                pTelefone_Res.DbType = System.Data.DbType.String;
            }

            SqlParameter pDDD_Com = new SqlParameter();
            pDDD_Com.ParameterName = "@DDD_Com";

            SqlParameter pTelefone_Com = new SqlParameter();
            pTelefone_Com.ParameterName = "@Telefone_Com";

            if (string.IsNullOrEmpty(a.Telefone_Com.ToString()))
            {
                pDDD_Com.Value = a.Telefone_Com;
                pDDD_Com.DbType = System.Data.DbType.String;

                pTelefone_Com.Value = a.Telefone_Com;
                pTelefone_Com.DbType = System.Data.DbType.String;
            }

            else
            {
                pDDD_Com.Value = a.Telefone_Com.Substring(1, 2);
                pDDD_Com.DbType = System.Data.DbType.String;

                pTelefone_Com.Value = a.Telefone_Com.Substring(5, 9);
                pTelefone_Com.DbType = System.Data.DbType.String;
            }

            SqlParameter pDDD_Cel = new SqlParameter();
            pDDD_Cel.ParameterName = "@DDD_Cel";

            SqlParameter pCelular = new SqlParameter();
            pCelular.ParameterName = "@Celular";

            if (string.IsNullOrEmpty(a.Celular.ToString()))
            {
                pDDD_Cel.Value = a.Celular;
                pDDD_Cel.DbType = System.Data.DbType.String;

                pCelular.Value = a.Celular;
                pCelular.DbType = System.Data.DbType.String;
            }

            else
            {
                pDDD_Cel.Value = a.Celular.Substring(1, 2);
                pDDD_Cel.DbType = System.Data.DbType.String;

                pCelular.Value = a.Celular.Substring(5, 10);
                pCelular.DbType = System.Data.DbType.String;
            }

            SqlParameter pCidade = new SqlParameter();
            pCidade.ParameterName = "@Cidade";
            pCidade.Value = a.Cidade;
            pCidade.DbType = System.Data.DbType.String;

            SqlParameter pEstado = new SqlParameter();
            pEstado.ParameterName = "@Estado";
            pEstado.Value = a.Estado;
            pEstado.DbType = System.Data.DbType.String;

            SqlParameter pCep = new SqlParameter();
            pCep.ParameterName = "@Cep";
            pCep.Value = a.Cep;
            pCep.DbType = System.Data.DbType.String;

            SqlParameter pEndereco = new SqlParameter();
            pEndereco.ParameterName = "@Endereco";
            pEndereco.Value = a.Endereco;
            pEndereco.DbType = System.Data.DbType.String;

            SqlParameter pEnderecoNumero = new SqlParameter();
            pEnderecoNumero.ParameterName = "@Endereco_Numero";
            pEnderecoNumero.Value = a.Endereco_Numero;
            pEnderecoNumero.DbType = System.Data.DbType.String;

            SqlParameter pComplemento = new SqlParameter();
            pComplemento.ParameterName = "@Complemento";
            pComplemento.Value = a.Complemento;
            pComplemento.DbType = System.Data.DbType.String;

            SqlParameter pBairro = new SqlParameter();
            pBairro.ParameterName = "@Bairro";
            pBairro.Value = a.Bairro;
            pBairro.DbType = System.Data.DbType.String;

            SqlParameter pEmail = new SqlParameter();
            pEmail.ParameterName = "@EMAIL";
            pEmail.Value = a.Email;
            pEmail.DbType = System.Data.DbType.String;

            SqlParameter pObservacoes = new SqlParameter();
            pObservacoes.ParameterName = "@Observacoes";
            pObservacoes.Value = a.Observacoes;
            pObservacoes.DbType = System.Data.DbType.String;

            cm.Parameters.Add(pNome);
            cm.Parameters.Add(pRG);
            cm.Parameters.Add(pCPF);
            cm.Parameters.Add(pDataNascimento);
            cm.Parameters.Add(pSexo);
            cm.Parameters.Add(pEstadoCivil);
            cm.Parameters.Add(pDDD_Res);
            cm.Parameters.Add(pTelefone_Res);
            cm.Parameters.Add(pDDD_Com);
            cm.Parameters.Add(pTelefone_Com);
            cm.Parameters.Add(pDDD_Cel);
            cm.Parameters.Add(pCelular);
            cm.Parameters.Add(pCidade);
            cm.Parameters.Add(pEstado);
            cm.Parameters.Add(pCep);
            cm.Parameters.Add(pEndereco);
            cm.Parameters.Add(pEnderecoNumero);
            cm.Parameters.Add(pComplemento);
            cm.Parameters.Add(pBairro);
            cm.Parameters.Add(pEmail);
            cm.Parameters.Add(pObservacoes);

            cn.Open();
            cm.ExecuteNonQuery();
            cn.Close();


        }

        public void AtualizarClientes(CadastroClientes cliente)
        {
            cm.Parameters.Clear();

            cm.CommandText = "PROC_ALTUALIZAR_TB_CLIENTES";
            cm.CommandType = CommandType.StoredProcedure;
            cm.CommandTimeout = 999999;

            SqlParameter pID_Cliente = new SqlParameter();
            pID_Cliente.ParameterName = "@ID_Cliente";
            pID_Cliente.Value = cliente.ID_Cliente;
            pID_Cliente.DbType = System.Data.DbType.Int32;

            SqlParameter pNome = new SqlParameter();
            pNome.ParameterName = "@Nome";
            pNome.Value = cliente.Nome;
            pNome.DbType = System.Data.DbType.String;

            SqlParameter pRG = new SqlParameter();
            pRG.ParameterName = "@RG";
            pRG.Value = cliente.RG;
            pRG.DbType = System.Data.DbType.String;

            SqlParameter pCPF = new SqlParameter();
            pCPF.ParameterName = "@CPF";
            pCPF.Value = cliente.CPF;
            pCPF.DbType = System.Data.DbType.String;

            SqlParameter pDataNascimento = new SqlParameter();
            pDataNascimento.ParameterName = "@Data_Nascimento";
            pDataNascimento.Value = cliente.Data_Nascimento;
            pDataNascimento.DbType = System.Data.DbType.Date;

            SqlParameter pSexo = new SqlParameter();
            pSexo.ParameterName = "@Sexo";
            pSexo.Value = cliente.Sexo;
            pSexo.DbType = System.Data.DbType.String;

            SqlParameter pEstadoCivil = new SqlParameter();
            pEstadoCivil.ParameterName = "@Estado_Civil";
            pEstadoCivil.Value = cliente.Estado_Civil;
            pEstadoCivil.DbType = System.Data.DbType.String;

            SqlParameter pDDD_Res = new SqlParameter();
            pDDD_Res.ParameterName = "@DDD_Res";

            SqlParameter pTelefone_Res = new SqlParameter();
            pTelefone_Res.ParameterName = "@Telefone_Res";

            if (string.IsNullOrEmpty(cliente.Telefone_Res.ToString()))
            {
                pDDD_Res.Value = cliente.Telefone_Res;
                pDDD_Res.DbType = System.Data.DbType.String;

                pTelefone_Res.Value = cliente.Telefone_Res;
                pTelefone_Res.DbType = System.Data.DbType.String;
            }
            else
            {
                pDDD_Res.Value = cliente.Telefone_Res.Substring(1, 2);
                pDDD_Res.DbType = System.Data.DbType.String;

                pTelefone_Res.Value = cliente.Telefone_Res.Substring(5, 9);
                pTelefone_Res.DbType = System.Data.DbType.String;
            }

            SqlParameter pDDD_Com = new SqlParameter();
            pDDD_Com.ParameterName = "@DDD_Com";

            SqlParameter pTelefone_Com = new SqlParameter();
            pTelefone_Com.ParameterName = "@Telefone_Com";

            if (string.IsNullOrEmpty(cliente.Telefone_Com.ToString()))
            {
                pDDD_Com.Value = cliente.Telefone_Com;
                pDDD_Com.DbType = System.Data.DbType.String;

                pTelefone_Com.Value = cliente.Telefone_Com;
                pTelefone_Com.DbType = System.Data.DbType.String;
            }

            else
            {
                pDDD_Com.Value = cliente.Telefone_Com.Substring(1, 2);
                pDDD_Com.DbType = System.Data.DbType.String;

                pTelefone_Com.Value = cliente.Telefone_Com.Substring(5, 9);
                pTelefone_Com.DbType = System.Data.DbType.String;
            }

            SqlParameter pDDD_Cel = new SqlParameter();
            pDDD_Cel.ParameterName = "@DDD_Cel";

            SqlParameter pCelular = new SqlParameter();
            pCelular.ParameterName = "@Celular";

            if (string.IsNullOrEmpty(cliente.Celular.ToString()))
            {
                pDDD_Cel.Value = cliente.Celular;
                pDDD_Cel.DbType = System.Data.DbType.String;

                pCelular.Value = cliente.Celular;
                pCelular.DbType = System.Data.DbType.String;
            }

            else
            {
                pDDD_Cel.Value = cliente.Celular.Substring(1, 2);
                pDDD_Cel.DbType = System.Data.DbType.String;

                pCelular.Value = cliente.Celular.Substring(5, 10);
                pCelular.DbType = System.Data.DbType.String;
            }

            SqlParameter pCidade = new SqlParameter();
            pCidade.ParameterName = "@Cidade";
            pCidade.Value = cliente.Cidade;
            pCidade.DbType = System.Data.DbType.String;

            SqlParameter pEstado = new SqlParameter();
            pEstado.ParameterName = "@Estado";
            pEstado.Value = cliente.Estado;
            pEstado.DbType = System.Data.DbType.String;

            SqlParameter pCep = new SqlParameter();
            pCep.ParameterName = "@Cep";
            pCep.Value = cliente.Cep;
            pCep.DbType = System.Data.DbType.String;

            SqlParameter pEndereco = new SqlParameter();
            pEndereco.ParameterName = "@Endereco";
            pEndereco.Value = cliente.Endereco;
            pEndereco.DbType = System.Data.DbType.String;

            SqlParameter pEnderecoNumero = new SqlParameter();
            pEnderecoNumero.ParameterName = "@Endereco_Numero";
            pEnderecoNumero.Value = cliente.Endereco_Numero;
            pEnderecoNumero.DbType = System.Data.DbType.String;

            SqlParameter pComplemento = new SqlParameter();
            pComplemento.ParameterName = "@Complemento";
            pComplemento.Value = cliente.Complemento;
            pComplemento.DbType = System.Data.DbType.String;

            SqlParameter pBairro = new SqlParameter();
            pBairro.ParameterName = "@Bairro";
            pBairro.Value = cliente.Bairro;
            pBairro.DbType = System.Data.DbType.String;

            SqlParameter pEmail = new SqlParameter();
            pEmail.ParameterName = "@EMAIL";
            pEmail.Value = cliente.Email;
            pEmail.DbType = System.Data.DbType.String;

            SqlParameter pObservacoes = new SqlParameter();
            pObservacoes.ParameterName = "@Observacoes";
            pObservacoes.Value = cliente.Observacoes;
            pObservacoes.DbType = System.Data.DbType.String;

            cm.Parameters.Add(pID_Cliente);
            cm.Parameters.Add(pNome);
            cm.Parameters.Add(pRG);
            cm.Parameters.Add(pCPF);
            cm.Parameters.Add(pDataNascimento);
            cm.Parameters.Add(pSexo);
            cm.Parameters.Add(pEstadoCivil);
            cm.Parameters.Add(pDDD_Res);
            cm.Parameters.Add(pTelefone_Res);
            cm.Parameters.Add(pDDD_Com);
            cm.Parameters.Add(pTelefone_Com);
            cm.Parameters.Add(pDDD_Cel);
            cm.Parameters.Add(pCelular);
            cm.Parameters.Add(pCidade);
            cm.Parameters.Add(pEstado);
            cm.Parameters.Add(pCep);
            cm.Parameters.Add(pEndereco);
            cm.Parameters.Add(pEnderecoNumero);
            cm.Parameters.Add(pComplemento);
            cm.Parameters.Add(pBairro);
            cm.Parameters.Add(pEmail);
            cm.Parameters.Add(pObservacoes);

            cn.Open();
            cm.ExecuteNonQuery();
            cn.Close();

        }

        public void DeletarClientes(int id)
        {
            cm.Parameters.Clear();

            cm.CommandText = "PROC_DELETAR_TB_CLIENTES";
            cm.CommandType = CommandType.StoredProcedure;
            cm.CommandTimeout = 999999;

            SqlParameter pID = new SqlParameter();
            pID.ParameterName = "@ID_CLIENTE";
            pID.Value = id;
            pID.DbType = System.Data.DbType.Int32;

            cm.Parameters.Add(pID);

            cn.Open();
            cm.ExecuteNonQuery();
            cn.Close();
        }

        public int DeletarClientesByList(List<CadastroClientes> lista)
        {
            int contador = 0;

            foreach (CadastroClientes cl in lista)
            {
                cm.Parameters.Clear();

                cm.CommandText = "PROC_DELETAR_TB_CLIENTES";
                cm.CommandType = CommandType.StoredProcedure;
                cm.CommandTimeout = 999999;

                SqlParameter pID_Cliente = new SqlParameter();
                pID_Cliente.ParameterName = "@ID_CLIENTE";
                pID_Cliente.Value = cl.ID_Cliente;
                pID_Cliente.DbType = System.Data.DbType.Int32;

                cm.Parameters.Add(pID_Cliente);

                cn.Open();
                cm.ExecuteNonQuery();
                cn.Close();

                contador++;
            }

            return contador;
        }
    }
}
